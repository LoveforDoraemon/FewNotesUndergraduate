# Notes-for-Linux
notes during learning Linux Cmd are listed here.
