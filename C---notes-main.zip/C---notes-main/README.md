# C---notes
notes during learing C
